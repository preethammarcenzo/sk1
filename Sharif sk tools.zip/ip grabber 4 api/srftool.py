import os
import requests, json
from concurrent.futures import ThreadPoolExecutor
import time
import platform
try:
	import shodan
	from colorama import Fore,Style
	import zoomeye.sdk as zoomeye 
	 
	


except:
	os.system('pip install colorama')
	os.system('pip install zoomeye')
	os.system('pip install shodan')
	



if platform=='win32':
   system('color')

if os.name == 'nt':
   os.system('cls')
else:
   os.system('clear')

banners = f"""
"""
print(banners)
choiceusers = input(f"{Fore.WHITE}[{Fore.WHITE}!{Fore.WHITE}]{Fore.WHITE} What Is 37 {Fore.WHITE} + 13 = {Fore.WHITE} :  {Style.RESET_ALL}")
if choiceusers == "50":

  banners = f"""
Login Sucess
\033[35m
░██████╗██╗░░██╗░█████╗░██████╗░██╗███████╗
██╔════╝██║░░██║██╔══██╗██╔══██╗██║██╔════╝
╚█████╗░███████║███████║██████╔╝██║█████╗░░
░╚═══██╗██╔══██║██╔══██║██╔══██╗██║██╔══╝░░
██████╔╝██║░░██║██║░░██║██║░░██║██║██║░░░░░
╚═════╝░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝╚═╝░░░░░

   Special thanks \033[35m@Srfxdz

{Fore.GREEN}[{Fore.WHITE}1{Fore.GREEN}] LARAVEL IP GRABBING BY LEAKIX
{Fore.GREEN}[{Fore.WHITE}2{Fore.GREEN}] LARAVEL IP GRABBING BY ZOOMEYE
{Fore.GREEN}[{Fore.WHITE}3{Fore.GREEN}] LARAVEL IP GRABBING BY SHODAN
{Fore.GREEN}[{Fore.WHITE}4{Fore.GREEN}] LARAVEL IP GRABBING BY NETLAS
{Fore.GREEN}[{Fore.WHITE}5{Fore.GREEN}] IP RANGER (MASS IP VAILIDATOR)


"""
print(banners)
choiceusers = input(f"{Fore.WHITE}•••••••••••>{Fore.WHITE}>  {Style.RESET_ALL}")

if choiceusers == "1":
   def grab(keywords):
       for pages in range(500000):
           print(f"\n{Fore.WHITE}Pages : {pages}{Style.RESET_ALL}")
           vars = 'https://leakix.net/search?page='+str(pages)+'&q='+keywords+'&scope=leak'
           headers = {'api-key': 's', 'Accept': 'application/json'}
           response = requests.get(vars, headers=headers).text
           tojson = json.loads(response)
           for results in tojson:
               lovs = results['ip']
               print(lovs)
               saves = open('leakix_IP.txt','a')
               saves.write(lovs+"\n")
               saves.close()

   keywords = input('\r\rEnter_Your_Dork_Here •••••••••••••>>').split()
   threads = input('\r\rEnter_Speed_Here •••••••••••••>>')
   if keywords:
     try:
        with ThreadPoolExecutor(int(threads)) as l:
            l.map(grab,keywords)
     except Exception as w:
        print(w)

elif choiceusers == "2":
   def grab(keywords):
       for pages in range(50000):
         print(f"\n{Fore.GREEN}Pages : {pages}{Style.RESET_ALL}")
         
         zm = zoomeye.ZoomEye()
         zm.username = "pepecav458@sceath.com"
         zm.password = "a1TPceenqWe"
         zm.login()
         data = zm.dork_search(keywords)
         print(zoomeye.show_site_ip(data)) 
         with open("zoomeye_IP.txt","a") as file:
             file.write(f"{zoomeye.show_site_ip}\n")

   keywords = input('\r\rQuery --> ').split()
   threads = input('\r\rThreads --> ')
   if keywords:
     try:
        with ThreadPoolExecutor(int(threads)) as l:
            l.map(grab,keywords)
     except Exception as w:
        print(w)

   keywords = input('\r\rEnter_Your_Dork_Here •••••••••••••>>').split()
   threads = input('\r\rEnter_Speed_Here •••••••••••••>>')
   if keywords:
     try:
        with ThreadPoolExecutor(int(threads)) as l:
            l.map(grab,keywords)
     except Exception as w:
        print(w)
      
elif choiceusers == "3":
   def grab(keywords):
       for pages in range(50000):
         print(f"\n{Fore.GREEN}Pages : {pages}{Style.RESET_ALL}")
         api = shodan.Shodan("NF5OqjinqrCIVu94Ytct78S8WYOf530m")
         results = api.search(keywords)
         for match in results['matches']:
            print(match['ip_str']) 
            with open("shodan_IP.txt","a") as file:
             file.write(f"{match['ip_str']}\n")

   keywords = input('\r\rQuery --> ').split()
   threads = input('\r\rThreads --> ')
   if keywords:
     try:
        with ThreadPoolExecutor(int(threads)) as l:
            l.map(grab,keywords)
     except Exception as w:
        print(w)

elif choiceusers == "4":
   def grab(keywords):
       for pages in range(1,50000):
           print(f"\n{Fore.GREEN}Pages : {pages}{Style.RESET_ALL}")
           vars = f"https://natlas.io/search?query={keywords}&page={str(pages)}&format=hostlist"
           headers = {
             'accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language' : 'en-GB,en-US;q=0.9,en;q=0.8'
            }
           response = requests.get(vars, headers=headers)
           print(response.text)
           with open("natlas_IP.txt","a") as file:
             file.write(f"{response.text}\n")
           
           
   keywords = input('\r\rEnter_Your_Dork_Here •••••••••••••>>').split()
   threads = input('\r\rEnter_Speed_Here •••••••••••••>>')
   if keywords:
     try:
        with ThreadPoolExecutor(int(threads)) as l:
            l.map(grab,keywords)
     except Exception as w:
        print(w)
elif choiceusers == "5":
     def ranges(xinputip):
         try:
            xstrip = "."
            xspl = xinputip.split(".")
            for xresult in range(0, 250 + 1):
                xres = xspl[0] + xstrip + xspl[1] + xstrip + xspl[2] + xstrip + str(xresult)
                print(f"[{Fore.RED}+{Style.RESET_ALL}]{Fore.GREEN} {xres}{Style.RESET_ALL}")
                open('ranged.txt','a').write(xres+"\n")
            for xresult in range(0, 250 + 1):
                xres2 = xspl[0] + xstrip + xspl[1] + xstrip + str(xresult) + xstrip + xspl[2]
                print(f"[{Fore.RED}+{Style.RESET_ALL}]{Fore.GREEN} {xres2}{Style.RESET_ALL}")
                open('ranged.txt','a').write(xres2+"\n")
         except:
            pass

     xinputip = open(input(f"{Fore.GREEN}[{Fore.RED}!{Fore.GREEN}] {Fore.WHITE}IP List{Fore.GREEN} --{Fore.RED}>  {Style.RESET_ALL}"), 'r').read().split("\n")
     thread = input(f"{Fore.GREEN}[{Fore.RED}!{Fore.GREEN}{Fore.WHITE} Threads {Fore.GREEN}--{Fore.RED}>  {Style.RESET_ALL}")
     if xinputip:
       try:
          with ThreadPoolExecutor(int(thread)) as pq:
              pq.map(ranges,xinputip)
       except:
          pass